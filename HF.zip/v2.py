import pygame as pg
import random

# Цвета (из вашего начального кода)
YELLOW = (200, 200, 0)
BLACK = (0, 0, 0)
WHITE = (255, 255, 255)
BLUE = (0, 0, 255)
GREEN = (0, 255, 0)
RED = (255, 0, 0)

# Размеры экрана
WIDTH = 1920
HEIGHT = 1080

pg.init()
screen = pg.display.set_mode((WIDTH, HEIGHT))

korabel = pg.image.load("fvubakamd1pc1.png").convert_alpha()
kosmos = pg.image.load("small-bubbles-foam.png").convert_alpha()
vrag_korabel = pg.image.load("images.png").convert_alpha()
# =====================================================================
# КЛАССЫ ИГРЫ
# =====================================================================

class Kosmos:
    
    def __init__(self, image, speed):
        # Масштабируем картинку пены/пузырей под размер игрового экрана
        self.image = pg.transform.scale(image, (WIDTH, HEIGHT))
        self.speed = speed
        
        # Две координаты Y для создания эффекта бесконечной ленты
        self.y1 = 0
        self.y2 = -HEIGHT

    def update(self):
        # Двигаем обе картинки вниз
        self.y1 += self.speed
        self.y2 += self.speed

        # Если верхняя картинка полностью ушла вниз, перебрасываем её наверх
        if self.y1 >= HEIGHT:
            self.y1 = -HEIGHT
            
        # То же самое для второй картинки
        if self.y2 >= HEIGHT:
            self.y2 = -HEIGHT

    def draw(self, screen):
        # Отрисовываем фон (сначала один кусочек, поверх него — второй)
        screen.blit(self.image, (0, self.y1))
        screen.blit(self.image, (0, self.y2))


class Korabel:
    
    def __init__(self, image):
        self.image = image
        self.rect = self.image.get_rect()
        
        # Начальная позиция: внизу экрана, строго по центру
        self.rect.centerx = WIDTH // 2
        self.rect.bottom = HEIGHT - 50
        self.speed = 10  # Скорость перемещения корабля

    def update(self):
        # Считываем нажатия клавиш (стрелочки и WASD)
        keys = pg.key.get_pressed()
        if keys[pg.K_LEFT] or keys[pg.K_a]:
            self.rect.x -= self.speed
        if keys[pg.K_RIGHT] or keys[pg.K_d]:
            self.rect.x += self.speed
        if keys[pg.K_UP] or keys[pg.K_w]:
            self.rect.y -= self.speed
        if keys[pg.K_DOWN] or keys[pg.K_s]:
            self.rect.y += self.speed
            
        # Ограничиваем движение, чтобы игрок не вылетал за границы экрана
        if self.rect.left < 0:
            self.rect.left = 0
        if self.rect.right > WIDTH:
            self.rect.right = WIDTH
        if self.rect.top < 0:
            self.rect.top = 0
        if self.rect.bottom > HEIGHT:
            self.rect.bottom = HEIGHT

    def draw(self, screen):
        screen.blit(self.image, self.rect)


class VragKorabel:
    
    def __init__(self, image):
        self.image = image
        self.rect = self.image.get_rect()
        
        # Появляется в случайном месте